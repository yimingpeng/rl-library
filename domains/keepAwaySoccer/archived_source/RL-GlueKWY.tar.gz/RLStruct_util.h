#ifndef RLStruct_Util_H
#define RLStruct_Util_H

#include "RL_common.h"

void copyRLStruct(RL_abstract_type& oldStruct, RL_abstract_type newStruct);

#endif
