/////////////////////////////
// This file is a wrapper
// that exists to call
// an agent compatabile
// with the RL-Glue framework
//
// *met 8/07
/////////////////////////////

#include <string.h>  // for memcpy
#include <stdlib.h>  // for rand
#include "LearningAgent.h" //*met 8/07

/* Constructor:
   numFeatures and numActions are required.  Additional parameter
   can be added to the constructor.  For example:
*/
LearningAgent::LearningAgent( int numFeatures, int numActions,
			      bool learning,
			      char *loadWeightsFile,
			      char *saveWeightsFile ):
  SMDPAgent( numFeatures, numActions )
{
  /* Contruct learner here */
  /* For example: */
  m_learning = learning;

  current_observation.numInts =0;
  current_observation.numDoubles = 13;  //Keepaway has 13 state variables
  current_observation.intArray =(int*)malloc(sizeof(int)*current_observation.numInts);
  memset(current_observation.intArray, 0, sizeof(int)*current_observation.numInts);
  current_observation.doubleArray = (double*)malloc(sizeof(double)*current_observation.numDoubles);
  memset(current_observation.doubleArray, 0, sizeof(double)*current_observation.numDoubles);

  agentServer.startServer();
  agentServer.acceptConnection();

  Task_specification ts = "";
  agent_init(ts);
}

/* Start Episode
   Use the current state to choose an action [0..numKeepers-1]
*/
int LearningAgent::startEpisode( double state[] )
{
  /* Choose first action */
  for (int i=0; i < (int)current_observation.numDoubles; i++){
    current_observation.doubleArray[i] = state[i];
  }
  m_lastAction = agent_start(current_observation).intArray[0];
  memcpy( m_lastState, state, getNumFeatures() * sizeof( double ) );
  return m_lastAction;
}

/* Step
   Update based on previous step and choose next action
*/
int LearningAgent::step( double reward, double state[] )
{
  //ro.r = reward;
  for (int i=0; i<(int)current_observation.numDoubles; i++){
    current_observation.doubleArray[i] = state[i];
  }
  if ( m_learning )
    m_lastAction = agent_step(reward, current_observation).intArray[0];
  memcpy( m_lastState, state, getNumFeatures() * sizeof( double ) );
  return m_lastAction;  
}

void LearningAgent::endEpisode( double reward )
{
  if ( m_learning ){
    //ro.r = reward;
    agent_end(reward);
  }
}
