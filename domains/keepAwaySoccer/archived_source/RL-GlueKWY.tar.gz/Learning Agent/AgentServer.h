#ifndef AgentServer_h
#define AgentServer_h

#include <Network/RL_network.h>

class AgentServer
{
protected:
  int serverSocket;
  bool onConnection(int client, rlBuffer &buffer);

public:
  void startServer();
  void acceptConnection();
};

#endif
