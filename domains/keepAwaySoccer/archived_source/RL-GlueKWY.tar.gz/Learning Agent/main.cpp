#include "AgentServer.h"

int main(int argc, char *argv[])
{
  AgentServer server;
  server.startServer();
  server.acceptConnection();
  return 0;
}
