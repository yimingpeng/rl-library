package rcssjava.gamelog;

class BallT 
    extends Struct 
{
    public long x;
    public long y;
    public long deltax;
    public long deltay;
}
