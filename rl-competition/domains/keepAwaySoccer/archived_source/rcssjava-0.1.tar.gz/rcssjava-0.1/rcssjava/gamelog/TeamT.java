package rcssjava.gamelog;

class TeamT 
    extends Struct
{
    public byte[] name;
    public short score;

    public TeamT()
    {
	name = new byte[ 16 ];
    }
}
